package com.jbk;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Test {
	public static void main(String[] args) {
		System.out.println("step 1");
		Configuration cfg=new Configuration();
		System.out.println("step 2");
		cfg.configure();
		System.out.println("step 3");
		
		cfg.addAnnotatedClass(team.class);
		System.out.println("step 4");
		
		SessionFactory sf= cfg.buildSessionFactory();
		Session session=sf.openSession();
		
		team ttt=session.load(team.class, 1);
		System.out.println(ttt);
		
		session.close();

	}

}
