package com.jbk;

import java.util.HashMap;

public class ss {
	public static void main(String[] args) {
		HashMap<Integer, String > mp=new HashMap<>();
		mp.put(1, "sumit");
		mp.put(2, "ram");
		mp.put(3, "pratu");
		System.out.println(mp);
		
	}

}
